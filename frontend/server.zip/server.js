const express = require('express');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');

const app = express();

app.use(express.json());
app.use(cors({
  origin: 'http://localhost:5173',
  credentials: true,
}));

// Dynamically generate a secret key on startup
const secretKey = require('crypto').randomBytes(32).toString('hex');

// In-memory storage
const users = [];
let forms = [];
let submissions = [];
let groups = [];
const tokenMap = new Map(); // { token: { user: { name, email }, expiresAt } }

// Clean up expired tokens every 10 minutes
setInterval(() => {
  const now = Date.now();
  for (const [token, { expiresAt }] of tokenMap.entries()) {
    if (expiresAt < now) {
      tokenMap.delete(token);
    }
  }
}, 10 * 60 * 1000);

app.use((req, res, next) => {
  console.log(`${req.method} ${req.url} - ${new Date().toISOString()}`);
  next();
});

app.get('/api/', authenticateToken, (req, res) => {
  console.log('Fetching dashboard data for:', req.user.email);
  const userEmail = req.user.email;
  const user = users.find(u => u.email === userEmail);
  if (!user) {
    return res.status(404).json({ message: 'User not found' });
  }

  const userForms = forms.filter(form => form.createdBy === userEmail);
  const formIds = userForms.map(form => form.id);
  const userSubmissions = submissions.filter(sub => formIds.includes(sub.formId));
  const userGroups = groups.filter(group => group.members.includes(userEmail));

  const dashboardData = {
    user: { name: user.name, email: user.email },
    stats: {
      totalForms: userForms.length,
      totalSubmissions: userSubmissions.length,
      totalGroups: userGroups.length,
    },
  };

  res.json(dashboardData);
});

app.post('/api/register', (req, res) => {
  console.log('Register attempt:', req.body);
  const { name, email, password } = req.body;
  if (!name || !email || !password) {
    console.log('Registration failed: Missing fields');
    return res.status(400).json({ message: 'Name, email, and password are required' });
  }
  if (users.some(user => user.email === email)) {
    console.log('Registration failed: Email already registered');
    return res.status(409).json({ message: 'Email already registered' });
  }
  users.push({ name, email, password });
  console.log('Registered users:', users);
  res.status(200).json({ message: 'Registration successful', userName: name });
});

app.post('/api/login', (req, res) => {
  console.log('Login attempt:', req.body);
  const { email, password } = req.body;
  if (!email || !password) {
    console.log('Login failed: Missing email or password');
    return res.status(400).json({ message: 'Email and password are required' });
  }
  const user = users.find(u => u.email === email && u.password === password);
  if (!user) {
    console.log('Login failed: Invalid credentials');
    return res.status(401).json({ message: 'Invalid credentials' });
  }

  try {
    // Check for existing valid token
    let existingToken = null;
    for (const [token, { user: tokenUser, expiresAt }] of tokenMap.entries()) {
      if (tokenUser.email === email && expiresAt > Date.now()) {
        existingToken = token;
        break;
      }
    }

    if (existingToken) {
      console.log('Returning existing token for:', email);
      return res.status(200).json({
        message: 'Login successful',
        userName: user.name,
        token: existingToken,
      });
    }

    // Generate new token
    const token = jwt.sign({ email }, secretKey, { expiresIn: '1h' });
    tokenMap.set(token, {
      user: { name: user.name, email: user.email },
      expiresAt: Date.now() + 60 * 60 * 1000, // 1 hour
    });
    console.log('Generated new token for:', email);
    res.status(200).json({
      message: 'Login successful',
      userName: user.name,
      token,
    });
  } catch (error) {
    console.error('Token generation failed:', error.message);
    res.status(500).json({ message: 'Failed to generate token' });
  }
});

app.post('/api/auth/validate', (req, res) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  console.log('Validating token:', token);

  if (!token) {
    console.log('No token provided');
    return res.status(401).json({ message: 'No token provided' });
  }

  const tokenData = tokenMap.get(token);
  if (tokenData && tokenData.expiresAt > Date.now()) {
    console.log('Token is valid for:', tokenData.user.email);
    return res.status(200).json({ message: 'Token is valid' });
  }

  // Token is invalid or expired, try to issue a new one
  try {
    const decoded = jwt.verify(token, secretKey, { ignoreExpiration: true });
    const user = users.find(u => u.email === decoded.email);
    if (!user) {
      console.log('User not found for expired token:', decoded.email);
      tokenMap.delete(token);
      return res.status(401).json({ message: 'User not found' });
    }

    // Generate new token
    const newToken = jwt.sign({ email: user.email }, secretKey, { expiresIn: '1h' });
    tokenMap.set(newToken, {
      user: { name: user.name, email: user.email },
      expiresAt: Date.now() + 60 * 60 * 1000,
    });
    tokenMap.delete(token);
    console.log('Issued new token for:', user.email);
    res.status(200).json({ message: 'Token refreshed', token: newToken });
  } catch (err) {
    console.log('Invalid token:', err.message);
    tokenMap.delete(token);
    return res.status(401).json({ message: 'Invalid token' });
  }
});

app.get('/api/forms', authenticateToken, (req, res) => {
  console.log('Fetching forms for:', req.user.email);
  const userEmail = req.user.email;
  res.json(forms.filter(form => form.createdBy === userEmail));
});

app.get('/api/forms/:id', authenticateToken, (req, res) => {
  console.log(`Fetching form ${req.params.id} for:`, req.user.email);
  const form = forms.find(f => f.id === req.params.id && f.createdBy === req.user.email);
  if (form) {
    res.json(form);
  } else {
    res.status(404).json({ message: 'Form not found or unauthorized' });
  }
});

app.post('/api/forms', authenticateToken, (req, res) => {
  console.log('Creating form for:', req.user.email, req.body);
  const form = {
    id: uuidv4(),
    title: req.body.title,
    fields: req.body.fields,
    status: req.body.status || 'Active',
    createdBy: req.user.email,
    createdAt: new Date().toISOString(),
    lastModified: new Date().toISOString(),
  };
  forms.push(form);
  res.status(201).json(form);
});

app.put('/api/forms/:id', authenticateToken, (req, res) => {
  console.log(`Updating form ${req.params.id} for:`, req.user.email, req.body);
  const index = forms.findIndex(f => f.id === req.params.id && f.createdBy === req.user.email);
  if (index !== -1) {
    forms[index] = {
      ...forms[index],
      title: req.body.title,
      fields: req.body.fields,
      status: req.body.status || forms[index].status,
      lastModified: new Date().toISOString(),
    };
    res.json(forms[index]);
  } else {
    res.status(404).json({ message: 'Form not found or unauthorized' });
  }
});

app.delete('/api/forms/:id', authenticateToken, (req, res) => {
  console.log(`Deleting form ${req.params.id} for:`, req.user.email);
  const index = forms.findIndex(f => f.id === req.params.id && f.createdBy === req.user.email);
  if (index !== -1) {
    forms.splice(index, 1);
    submissions = submissions.filter(sub => sub.formId !== req.params.id);
    res.status(204).send();
  } else {
    res.status(404).json({ message: 'Form not found or unauthorized' });
  }
});

app.post('/api/forms/:id/submissions', authenticateToken, (req, res) => {
  console.log(`Submitting form ${req.params.id} for:`, req.user.email, req.body);
  const form = forms.find(f => f.id === req.params.id);
  if (!form) {
    return res.status(404).json({ message: 'Form not found' });
  }
  const submission = {
    id: uuidv4(),
    formId: req.params.id,
    userEmail: req.user.email,
    data: req.body,
    submittedAt: new Date().toISOString(),
  };
  submissions.push(submission);
  res.status(201).json({ message: 'Submission successful', submission });
});

app.get('/api/forms/:id/submissions', authenticateToken, (req, res) => {
  console.log(`Fetching submissions for form ${req.params.id} for:`, req.user.email);
  const form = forms.find(f => f.id === req.params.id && f.createdBy === req.user.email);
  if (!form) {
    return res.status(404).json({ message: 'Form not found or unauthorized' });
  }
  const formSubmissions = submissions.filter(sub => sub.formId === req.params.id);
  res.json(formSubmissions);
});

app.get('/api/groups', authenticateToken, (req, res) => {
  console.log('Fetching groups for:', req.user.email);
  const userGroups = groups.filter(group => group.members.includes(req.user.email));
  res.json(userGroups);
});

app.post('/api/groups', authenticateToken, (req, res) => {
  console.log('Creating group for:', req.user.email, req.body);
  const group = {
    id: uuidv4(),
    name: req.body.name,
    members: [req.user.email, ...(req.body.members || [])],
    createdBy: req.user.email,
    createdAt: new Date().toISOString(),
  };
  groups.push(group);
  res.status(201).json(group);
});

app.delete('/api/groups/:id', authenticateToken, (req, res) => {
  console.log(`Deleting group ${req.params.id} for:`, req.user.email);
  const index = groups.findIndex(g => g.id === req.params.id && g.createdBy === req.user.email);
  if (index !== -1) {
    groups.splice(index, 1);
    res.status(204).send();
  } else {
    res.status(404).json({ message: 'Group not found or unauthorized' });
  }
});

app.delete('/api/users/:email', authenticateToken, (req, res) => {
  console.log(`Deleting user ${req.params.email}`);
  if (req.user.email !== req.params.email) {
    return res.status(403).json({ message: 'Unauthorized' });
  }
  users.splice(users.findIndex(u => u.email === req.params.email), 1);
  forms = forms.filter(form => form.createdBy !== req.params.email);
  submissions = submissions.filter(sub => sub.userEmail !== req.params.email);
  groups = groups.filter(group => group.createdBy !== req.params.email);
  groups.forEach(group => {
    group.members = group.members.filter(member => member !== req.params.email);
  });
  // Remove all tokens for this user
  for (const [token, { user }] of tokenMap.entries()) {
    if (user.email === req.params.email) {
      tokenMap.delete(token);
    }
  }
  res.status(204).send();
});

function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  console.log('Authenticating with token:', token);

  if (!token) {
    console.log('No token provided');
    return res.status(401).json({ message: 'No token provided' });
  }

  const tokenData = tokenMap.get(token);
  if (!tokenData || tokenData.expiresAt < Date.now()) {
    console.log('Invalid or expired token');
    tokenMap.delete(token);
    return res.status(401).json({ message: 'Invalid or expired token' });
  }

  req.user = tokenData.user;
  console.log('Token validated for:', req.user.email);
  next();
}

const PORT = 3000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));